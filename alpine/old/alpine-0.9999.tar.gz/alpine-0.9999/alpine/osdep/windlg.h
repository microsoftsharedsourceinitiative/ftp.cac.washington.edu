

/*----------------------------------------------------------------------------

	Common includes for custom dialogs.
		
	( This file included by os-win.h and os-wnt.h)

*/

