#define DLG_SPELL                   300

#define ID_COMBO_SUGGESTIONS        100
#define ID_BUTTON_CHANGE            IDOK
#define ID_BUTTON_CHANGEALL         101
#define ID_BUTTON_IGNOREONCE        102
#define ID_BUTTON_IGNOREALL         103
#define ID_BUTTON_ADD_TO_DICT       104
#define ID_BUTTON_CANCEL            IDCANCEL
