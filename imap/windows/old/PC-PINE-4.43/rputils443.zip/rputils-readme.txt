
            PC-Pine rputils version 4.43
                    November 2001


Copyright 1989-2001 University of Washington.
Pine and Pico are trademarks of the University of Washington.

rpload.exe and rpdump.exe are two command-line utilities for managing 
remote pinercs and address books.

rpload.exe - pine remote data utility

rpload [ -f ] [ -s trimSize ] -t Type -l Local_file -r Remote_folder

Rpload may be used to convert local Pine configuration files or
address books into remote configurations or address books.  It is
intended to be used by system admin istrators.  Regular users should
normally use the facilities provided within Pine.

Local_file will usually be a user's pine configuration file, and
Remote_folder is the IMAP folder which will be used (with the help of
Pine's -p, -P, and -x commands or PINECONF, PINERC, and PINERCEX
environment variables) as the user's remote configuration folder.  A
copy of Local_file will be placed in the folder with the correct
header lines to satisfy Pine.

  -f  Force the load even if the remote folder is in the wrong format.
      This will delete the contents of the folder so use it carefully.

  -s trimSize      
      If the number of messages in the remote folder is more
      than one plus trimsize (one is for the header mes sage), then
      messages 2, 3, and so on will be deleted until there are only
      one plus trimsize messages left.  If this option is not set no
      trimming will be done.

  -t Type
      The possible Types are pinerc, abook, and sig.  (Sig is mostly
      obsolete.  Literal signatures contained within the remote pinerc
      should be used instead.)

  -l Local_file
      The file on this system that is to be copied.

  -r Remote_folder
      A remote folder name to be copied to.  See the Pine
      documentation for the syntax of a remote folder name.  One
      example is {my.imap.server}remote_pinerc.

Exit status is zero if all goes well, -1 otherwise.


rpdump.exe - pine remote data utility

rpdump [ -f ] -l Local_file -r Remote_folder

Rpdump may be used to copy the actual data from remote Pine
configuration files or address books into a local file.  It is
intended to be used by system administrators.  Regular users should
normally use the facilities provided within Pine.

Local_file will normally be a local temporary file.  Remote_folder is
the IMAP folder being used as a remote Pine configuration (with the
help of Pine's -P, -p, and -x commands or PINECONF, PINERC, and
PINERCEX environment variables) or remote Pine address book folder. A
copy of the data from Remote_folder will be copied to Local_file.

  -f  Force the dump even if the remote folder is in an unrecognized
      format.

  -l  Local_file
      The file on this system that is to be copied to.

  -r  Remote_folder
      A remote folder name to be copied from.  See the Pine
      documentation for the syntax of a remote folder name.  One
      example is {my.imap.server}remote_pinerc.

Exit status is zero if all goes well, -1 otherwise.

2001.11.28 jpf
