ReadmeMapi32.txt
December 5, 2001
University of Washington

	      pmapi32 for PC-Pine 4.43 
		    revision 1

This distribution comes with two other files, instmapi.exe and pmapi32.dll, for
use with PC-Pine.  It is recommended that these files be put in your pine 
directory (generally C:\Program Files\Pine).  

pmapi32.dll - a Simple MAPI dynamically linked library.  pmapi32.dll is used 
by other applications to access your inbox or send mail through PC-Pine.

instmapi.exe - installs mapi32.dll such that registry values are set according 
to the location of pmapi32.dll, and possibly copies pmapi32.dll to the system
directory if it is run on older systems.  It will also offer to set PC-Pine 
as your default mailer and newsreader if it is not already set.  The "-silent"
option has been added to assume that default mailer and newsreader should be set and
also to suppress a "Successful Completion" alert. This program can be run repeatedly
without side effects.

instmapi.exe must be run at least once in order for pmapi32.dll to be accessible
to other applications.  As of PC-Pine 4.30, instmapi.exe may or may not need to be 
run in order for pmapi32.dll to work, depending on Windows/Internet Explorer/Microsoft
Office versions. To manually set PC-Pine as your default mailer, you must open 
"Internet Options" in your Control Panel and select the "Programs" tab.  Under 
"E-mail", select PC-Pine.

Troubleshooting:  To view debugging information, create a file called 
mapi_debug.txt in your system's %TEMP% directory.  Bug reports or comments
should be sent to pine@cac.washington.edu.

Jeff Franklin <jpf@cac.washington.edu>